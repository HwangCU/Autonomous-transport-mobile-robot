package kr.co.sl.tmapsample;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.skt.tmap.TMapAutoCompleteV2;
import com.skt.tmap.TMapBounds;
import com.skt.tmap.TMapData;
import com.skt.tmap.TMapGpsManager;
import com.skt.tmap.TMapInfo;
import com.skt.tmap.TMapLabelInfo;
import com.skt.tmap.TMapPoint;
import com.skt.tmap.TMapTapi;
import com.skt.tmap.TMapView;
import com.skt.tmap.address.TMapAddressInfo;
import com.skt.tmap.overlay.TMapCircle;
import com.skt.tmap.overlay.TMapMarkerItem;
import com.skt.tmap.overlay.TMapMarkerItem2;
import com.skt.tmap.overlay.TMapOverlay;
import com.skt.tmap.overlay.TMapPolyLine;
import com.skt.tmap.overlay.TMapPolygon;
import com.skt.tmap.poi.TMapPOIItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.HashMap;

import kr.co.sl.tmapsample.geofence.GeofenceData;
import kr.co.sl.tmapsample.geofence.Geofencer;
import kr.co.sl.tmapsample.postcode.PostCode;

public class MainActivity extends AppCompatActivity {

    private static final String API_KEY = "발급받은 앱키 입력";

    private TMapPoint initPoint;
    private Button menuButton;
    private DrawerLayout drawerLayout;
    private ImageView zoomInImage;
    private ImageView zoomOutImage;
    private ImageView locationImage;

    private TextView zoomLevelTextView;
    private TextView latitudeTextView;
    private TextView longitudeTextView;
    private TextView rotationTextView;
    private TextView pinchTextView;

    private ImageView centerImage;
    private TextView centerPointTextView;

    private ExpandableListView menuListView;

    private LinearLayout autoCompleteLayout;
    private EditText autoCompleteEdit;
    private ListView autoCompleteListView;
    private AutoCompleteListAdapter autoCompleteListAdapter;

    private LinearLayout autoComplete2Layout;
    private EditText autoComplete2Edit;
    private ListView autoComplete2ListView;
    private AutoComplete2ListAdapter autoComplete2ListAdapter;


    private LinearLayout routeLayout;
    private TextView routeDistanceTextView;
    private TextView routeTimeTextView;
    private TextView routeFareTextView;

    private boolean isReverseGeocoding;

    private TMapView tMapView;
    private int geofencingType;

    private int zoomIndex = -1;

    private boolean isVisibleCenter;
    private TMapGpsManager gpsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FrameLayout tmapLayout = findViewById(R.id.tmapLayout);

        initView();
        initTmap();

    }

    private void initTmap() {
        tMapView = new TMapView(this);
        tMapView.setSKTMapApiKey(API_KEY);

        tMapView.setOnMapReadyListener(onMapReadyListener);


        FrameLayout tmapLayout = findViewById(R.id.tmapLayout);
        tmapLayout.addView(tMapView);

        isReverseGeocoding = false;
        geofencingType = 0;

        tMapView.setOnEnableScrollWithZoomLevelListener(new TMapView.OnEnableScrollWithZoomLevelCallback() {
            @Override
            public void onEnableScrollWidthZoomLevel(float v, TMapPoint tMapPoint) {
                int zoom = (int) v;
                zoomIndex = zoom - 6;
                if (isVisibleCenter) {
                    setCenterPoint();
                }
            }
        });

        tMapView.setOnDisableScrollWithZoomLevelListener(new TMapView.OnDisableScrollWithZoomLevelCallback() {
            @Override
            public void onDisableScrollWidthZoomLevel(float v, TMapPoint tMapPoint) {
                reverseGeoCoding(isReverseGeocoding);
            }
        });

        tMapView.setOnClickListenerCallback(new TMapView.OnClickListenerCallback() {
            @Override
            public void onPressDown(ArrayList<TMapMarkerItem> arrayList, ArrayList<TMapPOIItem> arrayList1, TMapPoint tMapPoint, PointF pointF) {
                if (tMapView.isTrackingMode()) {
                    setTrackingMode(false);
                    locationImage.setSelected(false);
                }
            }

            @Override
            public void onPressUp(ArrayList<TMapMarkerItem> arrayList, ArrayList<TMapPOIItem> arrayList1, TMapPoint tMapPoint, PointF pointF) {
            }
        });

        // POI 클릭 리스너
        tMapView.setOnClickBasePOIListener(poiInfo -> {
            TMapData tmapdata = new TMapData();
            tmapdata.findPOIDetailInfo(poiInfo, arrayList -> {
                for (TMapPOIItem tMapPOIItem : arrayList) {
                    Log.d("TEST", "POI: " + tMapPOIItem);
                }
            });
        });
        // PAN 변경 리스너
        tMapView.setOnPanChangedListener(tMapPoint -> {
            latitudeTextView.setText(String.format("Lat: %s", tMapPoint.getLatitude()));
            longitudeTextView.setText(String.format("Lon: %s", tMapPoint.getLongitude()));
        });
        // ZOOM 변경 리스너
        tMapView.setOnZoomChangedListener(zoom -> {
            zoomLevelTextView.setText(String.format("Zoom: %s Lv", zoom));
        });
        // ROTATE 변경 리스너
        tMapView.setOnRotationChangedListener(rotate -> {
            rotationTextView.setText(String.format("Rotate: %s", rotate));
        });
        // Pinch 발생 리스너
        tMapView.setOnPinchListener(new TMapView.OnPinchListenerCallback() {
            @Override
            public void onPinchIn() {
                pinchTextView.setText(String.format("Pinch: %s", "IN"));
            }

            @Override
            public void onPinchOut() {
                pinchTextView.setText(String.format("Pinch: %s", "OUT"));
            }

            @Override
            public void onPinchStart() {
                tMapView.setUserScrollMoveEnable(false);
                pinchTextView.setText(String.format("Pinch: %s", "START"));
            }

            @Override
            public void onPinchEnd() {
                tMapView.setUserScrollMoveEnable(true);
                pinchTextView.setText(String.format("Pinch: %s", "END"));
            }
        });

        // Shape click listener
        tMapView.setOnClickShapeListenerCallback(new TMapView.OnClickShapeListenerCallback() {
            @Override
            public void onClickCircle(TMapCircle tMapCircle) {
                Toast.makeText(getApplicationContext(), "Circle: " + tMapCircle.getId(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onClickPolyLine(TMapPolyLine tMapPolyLine) {
                Toast.makeText(getApplicationContext(), "PolyLine: " + tMapPolyLine.getId(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onClickPolygon(TMapPolygon tMapPolygon) {
                Toast.makeText(getApplicationContext(), "Polygon: " + tMapPolygon.getId(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void reverseGeoCoding(boolean isReverseGeocoding) {

        this.isReverseGeocoding = isReverseGeocoding;

        if (this.isReverseGeocoding) {
            final TMapPoint centerPoint = tMapView.getCenterPoint();
            if (tMapView.isValidTMapPoint(centerPoint)) {
                TMapData tMapData = new TMapData();
                tMapData.reverseGeocoding(centerPoint.getLatitude(), centerPoint.getLongitude(), "A10", new TMapData.OnReverseGeocodingListener() {
                    @Override
                    public void onReverseGeocoding(TMapAddressInfo info) {
                        if (info != null) {
                            //법정동
                            String oldAddress = "법정동 : ";
                            if (info.strLegalDong != null && !info.strLegalDong.equals("")) {
                                oldAddress += info.strCity_do + " " + info.strGu_gun + " " + info.strLegalDong;
                                if (info.strRi != null && !info.strRi.equals("")) {
                                    oldAddress += (" " + info.strRi);
                                }
                                oldAddress += (" " + info.strBunji);
                            } else {
                                oldAddress += "-";
                            }

                            //새주소
                            String newAddress = "도로명 : ";
                            if (info.strRoadName != null && !info.strRoadName.equals("")) {
                                newAddress += info.strCity_do + " " + info.strGu_gun + " " + info.strRoadName + " " + info.strBuildingIndex;
                            } else {
                                newAddress += "-";
                            }

                            setReverseGeocoding(oldAddress, newAddress, centerPoint);

                        }
                    }
                });
            }
        } else {
            tMapView.removeAllTMapMarkerItem2();
        }

    }

    private void setReverseGeocoding(String oldAddress, String newAddress, TMapPoint point) {
        tMapView.removeAllTMapMarkerItem2();

        ReverseLabelView view = new ReverseLabelView(this);
        view.setText(oldAddress, newAddress);

        TMapMarkerItem2 marker = new TMapMarkerItem2("marker2");
        marker.setIconView(view);
        marker.setTMapPoint(point);

        tMapView.addTMapMarkerItem2View(marker);
    }

    private TMapView.OnMapReadyListener onMapReadyListener = new TMapView.OnMapReadyListener() {
        @Override
        public void onMapReady() {

            initPoint = tMapView.getCenterPoint();

            initAll();

            int zoom = tMapView.getZoomLevel();
            zoomIndex = zoom - 6;
        }
    };

    private void initView() {
        drawerLayout = findViewById(R.id.drawerLayout);
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

        menuButton = findViewById(R.id.menuButton);
        menuButton.setOnClickListener(onClickListener);
        zoomInImage = findViewById(R.id.zoomInImage);
        zoomInImage.setOnClickListener(onClickListener);
        zoomOutImage = findViewById(R.id.zoomOutImage);
        zoomOutImage.setOnClickListener(onClickListener);

        locationImage = findViewById(R.id.locationImage);
        locationImage.setOnClickListener(onClickListener);

        zoomLevelTextView = findViewById(R.id.zoomLevelText);
        latitudeTextView = findViewById(R.id.latitudeText);
        longitudeTextView = findViewById(R.id.longitudeText);
        rotationTextView = findViewById(R.id.rotationText);
        pinchTextView = findViewById(R.id.pinchText);

        centerImage = findViewById(R.id.centerIconImage);
        centerImage.setVisibility(View.GONE);
        centerPointTextView = findViewById(R.id.centerText);
        centerPointTextView.setVisibility(View.GONE);

        initAutoComplete();
        initAuto2Complete2();

        initRoute();

        menuListView = findViewById(R.id.menuListView);

        ArrayList<MenuItem> menuList = new ArrayList<>();

        MenuItem item0 = new MenuItem("초기화", new ArrayList<>());
        menuList.add(item0);

        ArrayList<String> child1 = new ArrayList<>();
        child1.add("줌 레벨 선택");
        child1.add("화면 중심좌표");
        child1.add("지도 타입 선택");
        child1.add("서클(원)");
        child1.add("직선");
        child1.add("폴리곤");
        child1.add("오버레이");
        child1.add("지도회전");
        child1.add("마커회전");
        child1.add("로고 보기");
        child1.add("POI 크기 설정");
        child1.add("지도 유형 설정");


        MenuItem item1 = new MenuItem("지도 컨트롤", child1);
        menuList.add(item1);

        ArrayList<String> child2 = new ArrayList<>();
        child2.add("POI통합검색");
        child2.add("주변POI검색");
        child2.add("읍면동/도로명조회");
        child2.add("POI자동완성");
        child2.add("POI초기화");
        child2.add("POI자동완성V2");
        MenuItem item2 = new MenuItem("POI", child2);
        menuList.add(item2);

        ArrayList<String> child3 = new ArrayList<>();
        child3.add("Reverse Geocoding");
        child3.add("Full Text Geocoding");
        child3.add("우편번호 검색");
        MenuItem item3 = new MenuItem("Geocoding", child3);
        menuList.add(item3);

        ArrayList<String> child4 = new ArrayList<>();
        child4.add("트래킹 모드");
        child4.add("나침반모드");
        child4.add("시야표출여부");
        child4.add("나침반모드 고정");
        MenuItem item4 = new MenuItem("위치트래킹", child4);
        menuList.add(item4);

        ArrayList<String> child5 = new ArrayList<>();
        child5.add("자동차 경로");
        child5.add("보행자 경로");
        child5.add("경로정보 전체삭제");
        MenuItem item5 = new MenuItem("경로안내", child5);
        menuList.add(item5);

        ArrayList<String> child6 = new ArrayList<>();
        MenuItem item6 = new MenuItem("Reverse Label", child6);
        menuList.add(item6);

        ArrayList<String> child7 = new ArrayList<>();
        child7.add("실행하기");
        child7.add("길안내");
        child7.add("통합검색");
        child7.add("주변 카페 검색");
        child7.add("주변 음식점 검색");
        child7.add("설치");
        MenuItem item7 = new MenuItem("Tmap연동", child7);
        menuList.add(item7);

        ArrayList<String> child8 = new ArrayList<>();
        MenuItem item8 = new MenuItem("Geofencing", child8);
        menuList.add(item8);

        ArrayList<String> child9 = new ArrayList<>();
        MenuItem item9 = new MenuItem("교통정보", child9);
        menuList.add(item9);

        MenuAdapter adapter = new MenuAdapter(this, menuList);
        menuListView.setAdapter(adapter);

        menuListView.setOnGroupClickListener((expandableListView, view, position, id) -> {

            if (position == 0 || position == 6 || position == 8 || position == 9) {
                selectMenu(position, -1);
                drawerLayout.closeDrawer(Gravity.LEFT);
                menuListView.collapseGroup(position);
            }

            return false;
        });


        menuListView.setOnChildClickListener((expandableListView, view, groupPosition, childPosition, id) -> {
            selectMenu(groupPosition, childPosition);
            drawerLayout.closeDrawer(Gravity.LEFT);
            return false;
        });

    }

    private void initRoute() {
        routeLayout = findViewById(R.id.routeLayout);
        routeDistanceTextView = findViewById(R.id.routeDistanceText);
        routeTimeTextView = findViewById(R.id.routeTimeText);
        routeFareTextView = findViewById(R.id.routeFareText);
    }

    private void initAuto2Complete2() {
        autoComplete2Layout = findViewById(R.id.autoComplete2Layout);
        autoComplete2Layout.setVisibility(View.GONE);
        autoComplete2Edit = findViewById(R.id.autoComplete2Edit);
        autoComplete2ListView = findViewById(R.id.autoComplete2ListView);
        autoComplete2ListAdapter = new AutoComplete2ListAdapter(this);
        autoComplete2ListView.setAdapter(autoComplete2ListAdapter);
        autoComplete2ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                tMapView.removeAllTMapMarkerItem();

                autoComplete2Layout.setVisibility(View.GONE);

                TMapAutoCompleteV2 item = (TMapAutoCompleteV2) autoComplete2ListAdapter.getItem(position);

                TMapMarkerItem marker = new TMapMarkerItem();
                marker.setId(item.poiId);
                marker.setIcon(BitmapFactory.decodeResource(getResources(), R.drawable.poi_dot));
                marker.setTMapPoint(Double.parseDouble(item.lat), Double.parseDouble(item.lon));
                marker.setCalloutTitle(item.keyword);
                marker.setCalloutSubTitle(item.poiId);
                marker.setCanShowCallout(true);
                marker.setAnimation(true);

                tMapView.addTMapMarkerItem(marker);

                tMapView.setCenterPoint(Double.parseDouble(item.lat), Double.parseDouble(item.lon));

            }
        });


        autoComplete2Edit.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                TMapData tMapData = new TMapData();

                String keyword = s.toString();
                double lat = tMapView.getCenterPoint().getLatitude();
                double lon = tMapView.getCenterPoint().getLongitude();

                tMapData.autoCompleteV2(keyword, lat, lon, 0, 100, new TMapData.OnAutoCompleteV2Listener() {
                    @Override
                    public void onAutoCompleteV2(ArrayList<TMapAutoCompleteV2> arrayList) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                autoComplete2ListAdapter.setItemList(arrayList);
                            }
                        });
                    }
                });
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void initAutoComplete() {
        autoCompleteLayout = findViewById(R.id.autoCompleteLayout);
        autoCompleteLayout.setVisibility(View.GONE);
        autoCompleteEdit = findViewById(R.id.autoCompleteEdit);
        autoCompleteListView = findViewById(R.id.autoCompleteListView);
        autoCompleteListAdapter = new AutoCompleteListAdapter(this);
        autoCompleteListView.setAdapter(autoCompleteListAdapter);
        autoCompleteListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String keyword = (String) autoCompleteListAdapter.getItem(position);

                findAllPoi(keyword);
                autoCompleteLayout.setVisibility(View.GONE);
            }
        });

        autoCompleteEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String keyword = s.toString();

                TMapData tMapData = new TMapData();

                tMapData.autoComplete(keyword, new TMapData.OnAutoCompleteListener() {
                    @Override
                    public void onAutoComplete(ArrayList<String> itemList) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                autoCompleteListAdapter.setItemList(itemList);
                            }
                        });

                    }
                });

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.equals(menuButton)) {
                drawerLayout.openDrawer(Gravity.LEFT);
            } else if (v.equals(zoomInImage)) {
                tMapView.mapZoomIn();
            } else if (v.equals(zoomOutImage)) {
                tMapView.mapZoomOut();
            } else if (v.equals(locationImage)) {
                locationImage.setSelected(!locationImage.isSelected());
                setTrackingMode(locationImage.isSelected());
            }
        }
    };


    private void selectMenu(int groupPosition, int childPosition) {
        if (groupPosition == 0) { // 초기화
            initAll();
        } else if (groupPosition == 1) { // 지도컨트롤
            if (childPosition == 0) { // 줌레벨 선택
                selectZoomLevel();
            } else if (childPosition == 1) { // 화면 중심좌표
                selectCenterPoint();
            } else if (childPosition == 2) { // 지도 타입 선택
                Toast.makeText(this, "지원하지 않습니다.", Toast.LENGTH_SHORT).show();
            } else if (childPosition == 3) { // 서클
                selectCircle();
            } else if (childPosition == 4) { // 직선
                selectLine();
            } else if (childPosition == 5) { // 폴리곤
                selectPolygon();
            } else if (childPosition == 6) { // 오버레이
                selectOverlay();
            } else if (childPosition == 7) { //지도 회전
                selectRotate();
            } else if (childPosition == 8) { // 마커 회전
                selectRotateMarker();
            } else if (childPosition == 9) { // 로고 보기
                selectVisibleLogo();
            } else if (childPosition == 10) { // poi 크기 설정
                selectPOIScale();
            } else if (childPosition == 11) { // 지도 유형 선택
                selectMapType();
            }
        } else if (groupPosition == 2) { // POI
            if (childPosition == 0) { // poi 통합검색
                findAllPoi();
            } else if (childPosition == 1) { // 주변 poi 검색
                findAroundPoi();
            } else if (childPosition == 2) { // 읍면동/도로명 조회
                findRoadPoi();
            } else if (childPosition == 3) { // poi 자동완성
                if (autoCompleteLayout.getVisibility() == View.GONE) {
                    autoCompleteLayout.setVisibility(View.VISIBLE);
                    autoCompleteListAdapter.clear();
                    autoCompleteEdit.setText("");
                } else {
                    autoCompleteLayout.setVisibility(View.GONE);
                }
            } else if (childPosition == 4) { // poi 초기화
                tMapView.removeAllTMapMarkerItem();
            } else if (childPosition == 5) { // poi 자동완성 v2
                if (autoComplete2Layout.getVisibility() == View.GONE) {
                    autoComplete2Layout.setVisibility(View.VISIBLE);
                    autoComplete2ListAdapter.clear();
                    autoComplete2Edit.setText("");
                } else {
                    autoComplete2Layout.setVisibility(View.GONE);
                }
            }

        } else if (groupPosition == 3) { // Geocoding
            if (childPosition == 0) { // reverse Geocoding
                selectReverseGeocoding();
            } else if (childPosition == 1) { // full Text Geocoding
                selectFullTextGeocoding();
            } else if (childPosition == 2) { // 우편번호 검색
                selectPostCode();
            }
        } else if (groupPosition == 4) { // 위치트래킹
            if (childPosition == 0) { // 트래킹모드
                selectTrackingMode();
            } else if (childPosition == 1) { // 나침반모드
                selectCompass();
            } else if (childPosition == 2) { // 시야표출여부
                selectSightVisible();
            } else if (childPosition == 3) { // 나침반모드 고정
                selectCompassFix();
            }
        } else if (groupPosition == 5) { // 경로안내
            if (childPosition == 0) { // 자동차 경로
                findPathAllType(TMapData.TMapPathType.CAR_PATH);
            } else if (childPosition == 1) { // 보행자 경로
                findPathAllType(TMapData.TMapPathType.PEDESTRIAN_PATH);
            }  else if (childPosition == 2) { // 경로 지우기
                tMapView.removeTMapPath();
                routeLayout.setVisibility(View.GONE);
            }
        } else if (groupPosition == 6) { // Reverse Label
            selectReverseLabel();
        } else if (groupPosition == 7) { // Tmap 연동
            if (childPosition == 0) { // 실행하기
                selectRunTMap();
            } else if (childPosition == 1) { // 길안내
                selectNaviTMap();
                new Handler().postDelayed(this::selectNaviTMap, 1000);
            } else if (childPosition == 2) { // 통합검색
                selectSearchTMap();
            } else if (childPosition == 3) { // 주변 카페 검색
                selectNearCafe();
            } else if (childPosition == 4) { // 주변 음식점 검색
                selectNearFood();
            } else if (childPosition == 5) { // 설치
                selectInstallTmap();
            }
        } else if (groupPosition == 8) { // Geofencing
            selectGeofencing();
        } else if (groupPosition == 9) {// 교통정보
            selectTraffic();
        }

    }


    private void selectMapType() {
        new AlertDialog.Builder(this)
                .setTitle("지도 유형 선택")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select5, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setMapType(TMapView.MapType.DEFAULT);
                        } else if (position == 1) {
                            tMapView.setMapType(TMapView.MapType.SATELLITE);
                        } else if (position == 2) {
                            tMapView.setMapType(TMapView.MapType.NIGHT);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }


    private void selectPOIScale() {
        new AlertDialog.Builder(this)
                .setTitle("POI 크기 설정")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select4, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setPOIScale(TMapView.POIScale.SMALL);
                        } else if (position == 1) {
                            tMapView.setPOIScale(TMapView.POIScale.NORMAL);
                        } else if (position == 2) {
                            tMapView.setPOIScale(TMapView.POIScale.LARGE);
                        }

                        dialog.dismiss();
                    }
                }).create().show();


    }

    private void selectOverlay() {
        new AlertDialog.Builder(this)
                .setTitle("오버레이 그리기")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select2, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.removeAllTMapOverlay();

                            TMapPoint centerPoint = randomTMapPoint();
                            tMapView.setCenterPoint(centerPoint.getLatitude(), centerPoint.getLongitude());
                            tMapView.setZoomLevel(13);

                            int centerX = tMapView.getWidth() / 2;
                            int centerY = tMapView.getHeight() / 2;

                            TMapPoint leftTop = tMapView.convertPointToGps(centerX - 100, centerY - 100);
                            TMapPoint rightBottom = tMapView.convertPointToGps(centerX + 100, centerY + 100);

                            TMapOverlay overlay = new TMapOverlay();
                            overlay.setId("overlay");
                            overlay.setOverlayImage(MainActivity.this, R.drawable.icon);
                            overlay.setLeftTopPoint(leftTop);
                            overlay.setRightBottomPoint(rightBottom);

                            tMapView.addTMapOverlay(overlay);


                        } else {
                            tMapView.removeAllTMapOverlay();
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectPostCode() {
        new PostCode(this, API_KEY).showFindPopup();
    }

    private void selectRotateMarker() {
        new AlertDialog.Builder(this)
                .setTitle("마커 회전")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setMarkerRotate(true);
                            tMapView.setPOIRotate(true);
                        } else {
                            tMapView.setMarkerRotate(false);
                            tMapView.setPOIRotate(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();

    }

    private void initAll() {
        tMapView.removeAllTMapMarkerItem2();
        tMapView.removeAllTMapMarkerItem();
        tMapView.removeAllTMapPolyLine();
        tMapView.removeAllTMapPolygon();
        tMapView.removeAllTMapCircle();
        tMapView.removeAllTMapPOIItem();
        tMapView.removeAllTMapOverlay();
        tMapView.removeTMapPath();

        tMapView.setPOIScale(TMapView.POIScale.NORMAL);

        routeLayout.setVisibility(View.GONE);

        tMapView.setCompassMode(false);
        tMapView.setSightVisible(false);
        tMapView.setZoomLevel(16);
        setTrackingMode(false);

        tMapView.setCenterPoint(initPoint.getLatitude(), initPoint.getLongitude());

        reverseGeoCoding(false);

        isVisibleCenter = false;
        centerPointTextView.setVisibility(View.GONE);
        centerImage.setVisibility(View.GONE);
        setCenterPoint();
    }

    private void setCenterPoint() {
        TMapPoint point = tMapView.getCenterPoint();
        String text = point.getLatitude() + "\n" + point.getLongitude();
        centerPointTextView.setText(text);

    }


    private void selectGeofencing() {
        final CharSequence regionNames[] = {"시,도 단위", "시,군,구 단위", "법정동", "행정동"};
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Geofencing").setIcon(R.drawable.tmark);
        final EditText input = new EditText(this);

        builder.setSingleChoiceItems(regionNames, geofencingType, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                geofencingType = whichButton;
            }
        }).setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tMapView.removeAllTMapPolygon();
                geofencing(input.getText().toString());
            }
        }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setView(input);
        builder.show();
    }


    Geofencer.OnGeofencingPolygonCreatedCallback geofencingCallback = new Geofencer.OnGeofencingPolygonCreatedCallback() {
        @Override
        public void onReceived(ArrayList<TMapPolygon> polygons) {
            if (polygons.size() > 0) {
                double latitudeSum = 0.0;
                double longitudeSum = 0.0;
                int zoomSum = 0;

                tMapView.removeAllTMapPolygon();

                for (int i = 0; i < polygons.size(); i++) {
                    polygons.get(i).setAreaColor(Color.BLACK);
                    polygons.get(i).setAreaAlpha(50);
                    tMapView.addTMapPolygon(polygons.get(i));
                    TMapInfo mapInfo = tMapView.getDisplayTMapInfo(polygons.get(i).getPolygonPoint());
                    latitudeSum += mapInfo.getPoint().getLatitude();
                    longitudeSum += mapInfo.getPoint().getLongitude();
                    zoomSum += mapInfo.getZoom();
                }
                tMapView.setZoomLevel((int) (zoomSum / polygons.size()));
                tMapView.setCenterPoint(latitudeSum / polygons.size(), longitudeSum / polygons.size());

            }
        }
    };

    private void geofencing(String regionName) {
        Geofencer geofencer = new Geofencer(API_KEY);
        geofencer.requestGeofencingBaseData(geofencer.getRegionTypeFromOrder(geofencingType), regionName, new Geofencer.OnGeofencingBaseDataReceivedCallback() {
            @Override
            public void onReceived(final ArrayList<GeofenceData> datas) {
                if (datas.size() == 1) {
//					Log.d("JSON Test", datas.get(0).getRegionId());
                    // 1개인경우 바로 draw
                    Geofencer geofencer2 = new Geofencer(API_KEY);
                    geofencer2.requestGeofencingPolygon(datas.get(0), geofencingCallback);
                } else if (datas.size() > 1) {
                    // 1개 이상인경우 리스트 표출하여 선택하도록
                    CharSequence[] regionNames = new CharSequence[datas.size()];
                    for (int i = 0; i < datas.size(); i++)
                        regionNames[i] = datas.get(i).getRegionName() + "/" + datas.get(i).getDescription();

                    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("결과내 선택").setIcon(R.drawable.tmark);

                    builder.setSingleChoiceItems(regionNames, -1, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Geofencer geofencer2 = new Geofencer(API_KEY);
                            geofencer2.requestGeofencingPolygon(datas.get(which), geofencingCallback);
                            dialog.dismiss();
                        }
                    });

                    builder.show();
                } else {
                    Toast.makeText(MainActivity.this, "검색에 실패하였습니다. 확인 후 다시 시도해주세요.", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void selectInstallTmap() {
        TMapTapi api = new TMapTapi(this);
        Uri uri = Uri.parse(api.getTMapDownUrl().get(0));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    private void selectNearCafe() {
        TMapTapi api = new TMapTapi(this);
//        api.invokeNearCafe(126.987040, 37.565118);
    }

    private void selectNearFood() {
        TMapTapi api = new TMapTapi(this);
//        api.invokeNearFood(126.987040, 37.565118);
    }

    private void selectSearchTMap() {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("TMap 통합 검색")
                .setView(input)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String searchText = input.getText().toString();

                        if (searchText.trim().length() > 0) {
                            TMapTapi api = new TMapTapi(MainActivity.this);
                            api.invokeSearchPortal(searchText);
                        }

                    }
                })
                .setNegativeButton("취소", null)
                .create().show();
    }

    private void selectNaviTMap() {
        final TMapPoint point = tMapView.getCenterPoint();
        if (tMapView.isValidTMapPoint(point)) {
            TMapData data = new TMapData();
            data.convertGpsToAddress(point.getLatitude(), point.getLongitude(), new TMapData.OnConvertGPSToAddressListener() {
                @Override
                public void onConverGPSToAddress(String s) {
                    TMapTapi tmaptapi = new TMapTapi(MainActivity.this);

                    HashMap<String, String> pathInfo = new HashMap<>();
                    pathInfo.put("rGoName", "T타워");
                    pathInfo.put("rGoX", "126.985302");
                    pathInfo.put("rGoY", "37.570841");

                    pathInfo.put("rStName", "출발지");
                    pathInfo.put("rStX", "126.926252");
                    pathInfo.put("rStY", "37.557607");

                    pathInfo.put("rV1Name", "경유지");
                    pathInfo.put("rV1X", "126.976867");
                    pathInfo.put("rV1Y", "37.576016");


                    pathInfo.put("rSOpt", "2");

                    //rSOpt
                    Log.e("mainactivity", "install ? " + tmaptapi.isTmapApplicationInstalled());
                    tmaptapi.invokeRoute(pathInfo);
                }
            });
        }
    }

    private void selectRunTMap() {
        TMapTapi api = new TMapTapi(this);

        api.invokeTmap();
    }

    private void selectTraffic() {
        new AlertDialog.Builder(this)
                .setTitle("교통정보")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setTrafficInfoActive(true);
                        } else {
                            tMapView.setTrafficInfoActive(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectReverseLabel() {
        new AlertDialog.Builder(this)
                .setTitle("Reverse Label")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            setReverseLabel(true);
                        } else {
                            setReverseLabel(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void setReverseLabel(boolean isReverse) {
        if (isReverse) {
            tMapView.setOnClickReverseLabelListener(new TMapView.OnClickReverseLabelListenerCallback() {
                @Override
                public void onClickReverseLabel(TMapLabelInfo info) {

                    ReverseLabelView view = new ReverseLabelView(MainActivity.this);
                    view.setText(info.getName(), info.getId());

                    TMapMarkerItem2 marker = new TMapMarkerItem2("reverseLabel");
                    marker.setTMapPoint(new TMapPoint(info.getLat(), info.getLon()));
                    marker.setIconView(view);

                    tMapView.removeTMapMarkerItem2("reverseLabel");
                    tMapView.addTMapMarkerItem2View(marker);

                }
            });
        } else {
            tMapView.removeTMapMarkerItem2("reverseLabel");
            tMapView.setOnClickReverseLabelListener(null);
        }
    }


    private void findPathAllType(final TMapData.TMapPathType type) {
        TMapPoint startPoint = tMapView.getCenterPoint();

        TMapPoint endPoint;
        if (type == TMapData.TMapPathType.CAR_PATH) {
            endPoint = randomTMapPoint2();
        } else {
            endPoint = randomTMapPoint();
        }

        TMapData data = new TMapData();
        new TMapData().findPathDataAllType(type, startPoint, endPoint, new TMapData.OnFindPathDataAllTypeListener() {
            @Override
            public void onFindPathDataAllType(Document doc) {
                tMapView.removeTMapPath();

                TMapPolyLine polyline = new TMapPolyLine();
                polyline.setID(type.name());
                polyline.setLineWidth(10);
                polyline.setLineColor(Color.RED);
                polyline.setLineAlpha(255);


                if (doc != null) {
                    NodeList list = doc.getElementsByTagName("Document");
                    Element item2 = (Element) list.item(0);
                    String totalDistance = getContentFromNode(item2, "tmap:totalDistance");
                    String totalTime = getContentFromNode(item2, "tmap:totalTime");
                    String totalFare;
                    if (type == TMapData.TMapPathType.CAR_PATH) {
                        totalFare = getContentFromNode(item2, "tmap:totalFare");
                    } else {
                        totalFare = "";
                    }

                    NodeList list2 = doc.getElementsByTagName("LineString");

                    for (int i = 0; i < list2.getLength(); i++) {
                        Element item = (Element) list2.item(i);
                        String str = getContentFromNode(item, "coordinates");
                        if (str == null) {
                            continue;
                        }

                        String[] str2 = str.split(" ");
                        for (int k = 0; k < str2.length; k++) {
                            try {
                                String[] str3 = str2[k].split(",");
                                TMapPoint point = new TMapPoint(Double.parseDouble(str3[1]), Double.parseDouble(str3[0]));
                                polyline.addLinePoint(point);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    tMapView.setTMapPath(polyline);

                    TMapInfo info = tMapView.getDisplayTMapInfo(polyline.getLinePointList());
                    int zoom = info.getZoom();
                    if (zoom > 12) {
                        zoom = 12;
                    }

                    tMapView.setZoomLevel(zoom);
                    tMapView.setCenterPoint(info.getPoint().getLatitude(), info.getPoint().getLongitude());


                    setPathText(totalDistance, totalTime, totalFare);
                }
            }
        });

    }

    private void setPathText(String distance, String time, String fare) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                routeLayout.setVisibility(View.VISIBLE);
                double km = Double.parseDouble(distance) / 1000;
                routeDistanceTextView.setText("총 거리 : " + km + " km");


                int totalSec = Integer.parseInt(time);
                int day = totalSec / (60 * 60 * 24);
                int hour = (totalSec - day * 60 * 60 * 24) / (60 * 60);
                int minute = (totalSec - day * 60 * 60 * 24 - hour * 3600) / 60;
                String t;
                if (hour > 0) {
                    t = hour + "시간 " + minute + "분";
                } else {
                    t = minute + "분 ";
                }
                routeTimeTextView.setText("예상시간 : 약 " + t);

                if (fare != null && !fare.equals("0") && !fare.equals("")) {
                    routeFareTextView.setVisibility(View.VISIBLE);
                    routeFareTextView.setText("유료도로 요금 : " + fare + " 원");
                } else {
                    routeFareTextView.setVisibility(View.GONE);
                }
            }
        });
    }



    private Bitmap createDrawableToBitmap(int resource) {
        Drawable d = getResources().getDrawable(resource);
        Canvas canvas = new Canvas();
        Bitmap b = Bitmap.createBitmap(d.getIntrinsicWidth(), d.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(b);
        ;
        d.setBounds(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        d.draw(canvas);

        return b;

    }


    private String getContentFromNode(Element item, String tagName) {
        NodeList list = item.getElementsByTagName(tagName);
        if (list.getLength() > 0) {
            if (list.item(0).getFirstChild() != null) {
                return list.item(0).getFirstChild().getNodeValue();
            }
        }
        return null;
    }

    private void selectCompassFix() {
        new AlertDialog.Builder(this)
                .setTitle("나침반 모드 고정")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setCompassModeFix(true);
                        } else {
                            tMapView.setCompassModeFix(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectCompass() {
        new AlertDialog.Builder(this)
                .setTitle("나침반 모드")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setCompassMode(true);
                        } else {
                            tMapView.setCompassMode(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectTrackingMode() {
        new AlertDialog.Builder(this)
                .setTitle("트래킹 모드")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            setTrackingMode(true);
                            locationImage.setSelected(true);
                        } else {
                            setTrackingMode(false);
                            locationImage.setSelected(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void setTrackingMode(boolean isTracking) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            boolean isGranted = true;
            String[] permissionArr = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
            ArrayList<String> checkPer = new ArrayList<>();
            for (String per : permissionArr) {
                if (checkSelfPermission(per) == PackageManager.PERMISSION_GRANTED) {

                } else {
                    checkPer.add(per);
                    isGranted = false;
                }
            }

            if (isGranted) {
                setTracking(isTracking);
            } else {
                requestPermissions(checkPer.toArray(new String[0]), 100);
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tMapView != null) {
            tMapView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (tMapView != null) {
            tMapView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tMapView != null) {
            tMapView.onDestroy();
        }
    }

    private void setTracking(boolean isTracking) {

        if (gpsManager == null) {
            gpsManager = new TMapGpsManager(this);
        }

        if (isTracking) {
            // gpsManager.setProvider(TMapGpsManager.PROVIDER_GPS);
            gpsManager.setProvider(TMapGpsManager.PROVIDER_NETWORK);
            gpsManager.openGps();

            // GPS, 방향 변경 이벤트 리스너
            gpsManager.setOnLocationChangeListener(location -> {
                // 위치 Tracking
                tMapView.setLocationPoint(location);
                tMapView.setCenterPoint(location.getLatitude(), location.getLongitude());

                TMapMarkerItem marker = new TMapMarkerItem();
                marker.setIcon(BitmapFactory.decodeResource(getResources(), R.drawable.location_marker));
                marker.setId("position");
                marker.setPosition(0.5f, 0.5f);
                marker.setTMapPoint(location);

                if (tMapView.getMarkerItemFromId("position") == null) {
                    tMapView.addTMapMarkerItem(marker);
                } else {
                    tMapView.updateTMapMarkerItem(marker);
                }
            });
        } else {
            gpsManager.setOnLocationChangeListener(null);
            tMapView.removeTMapMarkerItem("position");
        }
    }

    private void selectSightVisible() {
        new AlertDialog.Builder(this)
                .setTitle("시야표출여부")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setSightVisible(true);
                        } else {
                            tMapView.setSightVisible(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectFullTextGeocoding() {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("Full TextGeocoding")
                .setView(input)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        requestFullAddressGeo(input.getText().toString());

                    }
                })
                .setNegativeButton("취소", null)
                .create().show();
    }


    public class FullAddrData {
        public double lon = 0;
        public double lat = 0;
        public double lonEntr = 0;
        public double latEntr = 0;
        public String addr = "";
        public String flag = "";
    }

    private void requestFullAddressGeo(String strAddr) {
        // 지번주소 정확도 순 Flag( 인덱스 작은 수록 정확도 높음 )
        final String[] arrOldMatchFlag = {"M11", "M21", "M12", "M13", "M22", "M23", "M41", "M42", "M31", "M32", "M33"};
        // 도로명주소 정확도 순 Flag( 인덱스 작은 수록 정확도 높음 )
        final String[] arrNewMatchFlag = {"N51", "N52", "N53", "N54", "N55", "N61", "N62"};
        SLHttpRequest request = new SLHttpRequest("https://api2.sktelecom.com/tmap/geo/fullAddrGeo"); // SKT
        request.addParameter("version", "1");
        request.addParameter("appKey", API_KEY);
        request.addParameter("coordType", "WGS84GEO");
        request.addParameter("addressFlag", "F00");
        request.addParameter("fullAddr", strAddr);
        request.send(new SLHttpRequest.OnResponseListener() {

            @Override
            public void OnSuccess(String data) {
                // TODO Auto-generated method stub

                FullAddrData fullAddrData = new FullAddrData();

                // JsonParsing
                try {
                    ArrayList<String> alMatchFlag = new ArrayList<String>(); // MatchFlag 수집
                    int indexMatchFlag = -1;
                    int i, j;

                    JSONObject objData = new JSONObject(data).getJSONObject("coordinateInfo");
                    int length = objData.getInt("totalCount");
                    JSONArray arrCoordinate = objData.getJSONArray("coordinate");
                    JSONObject objCoordinate = null;

                    // 1. matchFlag 수집
                    for (i = 0; i < length; i++) {
                        objCoordinate = arrCoordinate.getJSONObject(i);

                        if (objCoordinate.getString("matchFlag") != null && !objCoordinate.getString("matchFlag").equals("")) {
                            // 지번주소
                            alMatchFlag.add(objCoordinate.getString("matchFlag"));
                        } else if (objCoordinate.getString("newMatchFlag") != null && !objCoordinate.getString("newMatchFlag").equals("")) {
                            // 도로명주소
                            alMatchFlag.add(objCoordinate.getString("newMatchFlag"));
                        }
                    }

                    // 2. < matchFlag 기준으로 더 정확한 항목의 index 결정 >
                    // 2_1. 수집한 matchFlag 중 "M11"(지번주소중 가장 높은정확도) 이 있으면 선택
                    for (i = 0; i < alMatchFlag.size(); i++) {
                        if (alMatchFlag.get(i).equals("M11")) {
                            indexMatchFlag = i;
                            break;
                        }
                    }

                    // 2_2. "M11" 없으면 arrNewMatchFlag(도로명주소) 에서 선택
                    if (indexMatchFlag == -1) {
                        for (i = 0; i < arrNewMatchFlag.length; i++) {
                            for (j = 0; j < alMatchFlag.size(); j++) {
                                if (alMatchFlag.get(j).equals(arrNewMatchFlag[i])) {
                                    indexMatchFlag = j;
                                    break;
                                }
                            }
                            if (indexMatchFlag != -1) {
                                break;
                            }
                        }
                    }
                    // 2_3. 도로명주소 없으면 arrOldMatchFlag(지번주소) 에서 선택
                    if (indexMatchFlag == -1) {
                        for (i = 0; i < arrOldMatchFlag.length; i++) {
                            for (j = 0; j < alMatchFlag.size(); j++) {
                                if (alMatchFlag.get(j).equals(arrOldMatchFlag[i])) {
                                    indexMatchFlag = j;
                                    break;
                                }
                            }
                            if (indexMatchFlag != -1) {
                                break;
                            }
                        }
                    }

                    // 3. 선택된 인덱스의 결과 세팅
                    if (indexMatchFlag != -1) {
                        objCoordinate = arrCoordinate.getJSONObject(indexMatchFlag);
                        if (!objCoordinate.getString("matchFlag").equals("")) {
                            // 지번 주소
                            if (!objCoordinate.getString("lat").equals(""))
                                fullAddrData.lat = Double.parseDouble(objCoordinate.getString("lat"));
                            if (!objCoordinate.getString("lon").equals(""))
                                fullAddrData.lon = Double.parseDouble(objCoordinate.getString("lon"));
                            if (!objCoordinate.getString("latEntr").equals(""))
                                fullAddrData.latEntr = Double.parseDouble(objCoordinate.getString("latEntr"));
                            if (!objCoordinate.getString("lonEntr").equals(""))
                                fullAddrData.lonEntr = Double.parseDouble(objCoordinate.getString("lonEntr"));
                            fullAddrData.addr = objCoordinate.getString("city_do") + " " + objCoordinate.getString("gu_gun") + " " + objCoordinate.getString("legalDong") + " " + objCoordinate.getString("bunji");
                            fullAddrData.flag = objCoordinate.getString("matchFlag");
                        } else if (!objCoordinate.getString("newMatchFlag").equals("")) {
                            // 도로명 주소
                            if (!objCoordinate.getString("newLat").equals(""))
                                fullAddrData.lat = Double.parseDouble(objCoordinate.getString("newLat"));
                            if (!objCoordinate.getString("newLon").equals(""))
                                fullAddrData.lon = Double.parseDouble(objCoordinate.getString("newLon"));
                            if (!objCoordinate.getString("newLatEntr").equals(""))
                                fullAddrData.latEntr = Double.parseDouble(objCoordinate.getString("newLatEntr"));
                            if (!objCoordinate.getString("newLonEntr").equals(""))
                                fullAddrData.lonEntr = Double.parseDouble(objCoordinate.getString("newLonEntr"));
                            fullAddrData.addr = objCoordinate.getString("city_do") + " " + objCoordinate.getString("gu_gun") + " " + objCoordinate.getString("newRoadName") + " " + objCoordinate.getString("newBuildingIndex") + " " + objCoordinate.getString("newBuildingDong") + " (" + objCoordinate.getString("zipcode") + ")";
                            fullAddrData.flag = objCoordinate.getString("newMatchFlag");
                        }
                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Log.d("debug", e.toString());
                }

                //listener.onComplete(fullAddrData);

                setFullTextGeoCoding(fullAddrData);
            }

            @Override
            public void OnFail(int errorCode, String errorMessage) {
                // TODO Auto-generated method stub
                Log.d("debug", "errorMessage :" + errorMessage);
                //listener.onComplete(null);
            }
        });
    }

    private void setFullTextGeoCoding(final FullAddrData fullAddrData) {
        tMapView.removeAllTMapMarkerItem2();

        if (fullAddrData.lat != 0) {
            //중심좌표 있을 경우
            String address1 = fullAddrData.addr;
            String address2 = fullAddrData.flag + " : " + getFullAddrGeoFlagInfo(fullAddrData.flag);
            ReverseLabelView view = new ReverseLabelView(this);
            view.setText(address1, address2);

            TMapMarkerItem2 marker = new TMapMarkerItem2("fullTextGeocoding");
            marker.setTMapPoint(new TMapPoint(fullAddrData.lat, fullAddrData.lon));
            marker.setIconView(view);

            tMapView.addTMapMarkerItem2View(marker);
            tMapView.setCenterPoint(fullAddrData.lat, fullAddrData.lon);

        }

        if (fullAddrData.latEntr != 0) {
            // 입구좌표 있을 경우
            ArrayList<Bitmap> iconList = new ArrayList<>();
            iconList.add(BitmapFactory.decodeResource(getResources(), R.drawable.poi_dot));
            TMapMarkerItem2 marker = new TMapMarkerItem2("fullTextGeocoding_" + "Entr");
            marker.setIconList(iconList);
            marker.setTMapPoint(new TMapPoint(fullAddrData.latEntr, fullAddrData.lonEntr));

            tMapView.addTMapMarkerItem2Icon(marker);
            tMapView.setCenterPoint(fullAddrData.latEntr, fullAddrData.lonEntr);
        }
    }

    public String getFullAddrGeoFlagInfo(String flag) {
        if (flag != null && !flag.equals("")) {
            if (flag.equals("M11")) {
                return "법정동 코드 + 지번이 모두 일치";
            } else if (flag.equals("M12")) {
                return "법정동 코드 + 지번의 주번이 같고 부번이 ±5 이내로 부번과 일치";
            } else if (flag.equals("M13")) {
                return "법정동 코드 + 지번의 주번이 동일하지 않고 ±5 이내로 주번과 일치";
            } else if (flag.equals("M21")) {
                return "행정동 코드 + 지번이 모두 일치";
            } else if (flag.equals("M22")) {
                return "행정동 코드 + 지번의 주번이 같고 부번이 ±5 이내로 부번과 일치";
            } else if (flag.equals("M23")) {
                return "행정동 코드 + 지번의 주번이 동일하지 않고 ±5 이내로 주번과 일치";
            } else if (flag.equals("M31")) {
                return "읍/면/동/리의 중심 매칭";
            } else if (flag.equals("M32")) {
                return "행정동의 중심 매칭";
            } else if (flag.equals("M33")) {
                return "법정동의 중심 매칭";
            } else if (flag.equals("M41")) {
                return "법정동 코드 + 건물명칭이 일치(동일 법정동 내 동일 건물명이 없다는 전제)";
            } else if (flag.equals("M42")) {
                return "법정동 코드 + 건물 동이 매칭";
            } else if (flag.equals("N51")) {
                return "새(도로명) 주소 도로명이 일치하고 건물의 주번/부번이 모두 일치";
            } else if (flag.equals("N52")) {
                return "2차 종속도로에서 주번이 같고 부번이 다름(직전 부번[좌/우 구분]의 끝 좌표를 반환)";
            } else if (flag.equals("N53")) {
                return "1차 종속도로에서 주번이 같고 부번이 다름(직전 부번[좌/구 구분]의 끝 좌표를 반환)";
            } else if (flag.equals("N54")) {
                return "0차 종속도로에서 주번이 같은 것이 없어서 가장 가까운 직전 주번[좌/우 구분]의 가장 끝 좌표";
            } else if (flag.equals("N55")) {
                return "새(도로명) 주소 도로명은 일치하나 주번/부번의 직전 근사값이 없는 경우, 새(도로명) 주소 길 중심 좌표를 반환";
            } else if (flag.equals("N61")) {
                return "새(도로명) 주소 도로명이 틀리나 동일구 내 1개의 건물명과 일치하는 경우, 해당하는 건물 좌표를 반환";
            } else if (flag.equals("N62")) {
                return "새주소 도로명이 틀리나 동일구 내 1개의 건물명과 동명이 일치하는 경우, 해당하는 건물 좌표를 반환";
            } else {
                return "해당 matchFlag 에 대한 설명이 없습니다.";
            }
        } else {
            return "matchFlag 가 비어있습니다.";
        }
    }

    private void selectReverseGeocoding() {
        new AlertDialog.Builder(this)
                .setTitle("Reverse Geocoding")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            reverseGeoCoding(true);
                        } else {
                            reverseGeoCoding(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void findRoadPoi() {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("읍면동/도로명 조회")
                .setView(input)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        tMapView.removeAllTMapMarkerItem();
                        TMapData tMapData = new TMapData();
                        tMapData.findPoiAreaDataByName(input.getText().toString(), 10, 1, new TMapData.OnFindPoiAreaDataByNameListener() {
                            @Override
                            public void onFindPoiAreaDataByName(ArrayList<TMapPOIItem> poiList) {

                                ArrayList<TMapPoint> pointList = new ArrayList<>();

                                for (int i = 0; i < poiList.size(); i++) {
                                    TMapPOIItem poi = poiList.get(i);
                                    TMapMarkerItem marker = new TMapMarkerItem();
                                    marker.setId("marker" + i);
                                    marker.setIcon(BitmapFactory.decodeResource(getResources(), R.drawable.poi_dot));
                                    marker.setTMapPoint(poi.getPOIPoint());
                                    marker.setCalloutTitle(poi.getPOIName());
                                    marker.setCanShowCallout(true);
                                    marker.setAnimation(true);

                                    tMapView.addTMapMarkerItem(marker);
                                    pointList.add(poi.getPOIPoint());
                                }
                                TMapInfo info = tMapView.getDisplayTMapInfo(pointList);
                                tMapView.setZoomLevel(info.getZoom());
                                tMapView.setCenterPoint(info.getPoint().getLatitude(), info.getPoint().getLongitude());

                            }
                        });
                    }
                })
                .setNegativeButton("취소", null)
                .create().show();
    }

    private void findAroundPoi() {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("주변 POI 검색")
                .setMessage("ex) 편의점, 약국, 은행 등..")
                .setView(input)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        TMapData tMapData = new TMapData();
                        tMapData.findAroundNamePOI(tMapView.getCenterPoint(), input.getText().toString(), 1, 99, new TMapData.OnFindAroundNamePOIListener() {
                            @Override
                            public void onFindAroundNamePOI(ArrayList<TMapPOIItem> arrayList) {
                                tMapView.removeAllTMapMarkerItem();
                                ArrayList<TMapPoint> pointList = new ArrayList<>();
                                if (arrayList != null) {

                                    for (TMapPOIItem item : arrayList) {

                                        tMapView.addTMapPOIItem(arrayList);
                                        pointList.add(item.getPOIPoint());
                                    }

                                    TMapInfo info = tMapView.getDisplayTMapInfo(pointList);
                                    tMapView.setZoomLevel(info.getZoom());
                                    tMapView.setCenterPoint(info.getPoint().getLatitude(), info.getPoint().getLongitude());

                                }
                            }
                        });
                    }
                })
                .setNegativeButton("취소", null)
                .create().show();
    }

    private void findAllPoi() {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("POI 통합 검색")
                .setView(input)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        findAllPoi(input.getText().toString());
                    }
                })
                .setNegativeButton("취소", null)
                .create().show();
    }

    public void findAllPoi(String strData) {
        TMapData tmapdata = new TMapData();
        tmapdata.findAllPOI(strData, new TMapData.OnFindAllPOIListener() {
            @Override
            public void onFindAllPOI(ArrayList<TMapPOIItem> poiItemList) {
                showPOIResultDialog(poiItemList);
            }
        });
    }

    private void showPOIResultDialog(final ArrayList<TMapPOIItem> poiItem) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (poiItem != null) {
                    CharSequence[] item = new CharSequence[poiItem.size()];
                    for (int i = 0; i < poiItem.size(); i++) {
                        item[i] = poiItem.get(i).name;
                    }
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("POI 검색 결과")
                            .setIcon(R.drawable.tmark)
                            .setItems(item, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int i) {
                                    dialog.dismiss();
                                    initAll();
                                    TMapPOIItem poi = poiItem.get(i);
                                    TMapMarkerItem marker = new TMapMarkerItem();
                                    marker.setId(poi.id);
                                    marker.setTMapPoint(poi.getPOIPoint());
                                    Bitmap icon = BitmapFactory.decodeResource(getResources(), R.drawable.poi_dot);
                                    marker.setIcon(icon);

                                    marker.setCalloutTitle(poi.getPOIName());
                                    marker.setCalloutSubTitle("id:" + poi.getPOIID());
                                    marker.setCanShowCallout(true);

                                    marker.setAnimation(true);

                                    tMapView.addTMapMarkerItem(marker);
                                    tMapView.setCenterPoint(poi.getPOIPoint().getLatitude(), poi.getPOIPoint().getLongitude());
                                }
                            }).create().show();
                }

            }
        });

    }

    private void selectVisibleLogo() {
        new AlertDialog.Builder(this)
                .setTitle("로고 보기")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setVisibleLogo(true);
                        } else {
                            tMapView.setVisibleLogo(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectRotate() {
        new AlertDialog.Builder(this)
                .setTitle("지도회전 여부")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select3, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.setRotateEnable(true);
                        } else {
                            tMapView.setRotateEnable(false);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectPolygon() {
        new AlertDialog.Builder(this)
                .setTitle("폴리곤 그리기")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select2, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.removeAllTMapPolygon();
                            int Min = 3;
                            int Max = 10;
                            int rndNum = (int) (Math.random() * (Max - Min));

                            TMapPolygon polygon = new TMapPolygon();
                            polygon.setId("polygon");
                            polygon.setLineColor(Color.BLUE);
                            polygon.setAreaColor(Color.RED);
                            polygon.setAreaAlpha(50);
                            polygon.setLineAlpha(255);
                            polygon.setPolygonWidth(4);

                            TMapPoint point = null;

                            if (rndNum < 3) {
                                rndNum = rndNum + (3 - rndNum);
                            }

                            for (int i = 0; i < rndNum; i++) {
                                point = randomTMapPoint();
                                polygon.addPolygonPoint(point);
                            }

                            TMapInfo info = tMapView.getDisplayTMapInfo(polygon.getPolygonPoint());
                            tMapView.setZoomLevel(info.getZoom());
                            tMapView.setCenterPoint(info.getPoint().getLatitude(), info.getPoint().getLongitude());

                            tMapView.addTMapPolygon(polygon);

                        } else {
                            tMapView.removeAllTMapPolygon();
                        }
                        dialog.dismiss();
                    }
                }).create().show();


    }

    private void selectLine() {
        new AlertDialog.Builder(this)
                .setTitle("직선 그리기")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select2, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position) {
                        if (position == 0) {
                            tMapView.removeAllTMapPolyLine();

                            TMapPolyLine line = new TMapPolyLine();
                            line.setID("line");
                            line.setLineColor(Color.BLUE);
                            line.setLineAlpha(255);
                            line.setLineWidth(5);

                            line.setOutLineColor(Color.RED);
                            line.setOutLineAlpha(255);
                            line.setOutLineWidth(7);


                            for (int i = 0; i < 5; i++) {
                                TMapPoint point = randomTMapPoint();
                                line.addLinePoint(point);
                            }

                            tMapView.addTMapPolyLine(line);

                            TMapInfo info = tMapView.getDisplayTMapInfo(line.getLinePointList());
                            tMapView.setZoomLevel(info.getZoom());
                            tMapView.setCenterPoint(info.getPoint().getLatitude(), info.getPoint().getLongitude());
                        } else {
                            tMapView.removeAllTMapPolyLine();
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    int circleIndex = 0;

    private void selectCircle() {
        new AlertDialog.Builder(this)
                .setTitle("서클(원) 그리기")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select2, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        if (i == 0) {
                            TMapCircle circle = new TMapCircle();
                            circle.setId("circle" + circleIndex++);
                            circle.setRadius(300);
                            circle.setAreaColor(Color.BLUE);
                            circle.setLineColor(Color.BLUE);
                            circle.setAreaAlpha(100);
                            circle.setLineAlpha(255);
                            circle.setCircleWidth(10);
                            circle.setRadiusVisible(true);

                            TMapPoint point = randomTMapPoint();
                            circle.setCenterPoint(point);

                            tMapView.setCenterPoint(point.getLatitude(), point.getLongitude());
                            tMapView.addTMapCircle(circle);
                        } else {
                            tMapView.removeAllTMapCircle();
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }


    private void selectCenterPoint() {

        new AlertDialog.Builder(this)
                .setTitle("화면중심좌표")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.select1, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        if (i == 0) {
                            isVisibleCenter = true;
                            centerImage.setVisibility(View.VISIBLE);
                            centerPointTextView.setVisibility(View.VISIBLE);


                        } else {
                            isVisibleCenter = false;
                            centerImage.setVisibility(View.GONE);
                            centerPointTextView.setVisibility(View.GONE);
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    private void selectZoomLevel() {
        String[] zoomItemArr = getResources().getStringArray(R.array.zoom_level_array);
        new AlertDialog.Builder(this)
                .setTitle("줌 레벨 선택")
                .setIcon(R.drawable.tmark)
                .setSingleChoiceItems(R.array.zoom_level_array, zoomIndex, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        zoomIndex = i;
                        int zoom = Integer.parseInt(zoomItemArr[i]);
                        tMapView.setZoomLevel(zoom);
                        dialogInterface.dismiss();
                    }
                })
                .create()
                .show();
    }

    public TMapPoint randomTMapPoint() {
        double latitude = ((double) Math.random()) * (37.575113 - 37.483086) + 37.483086;
        double longitude = ((double) Math.random()) * (127.027359 - 126.878357) + 126.878357;

        latitude = Math.min(37.575113, latitude);
        latitude = Math.max(37.483086, latitude);

        longitude = Math.min(127.027359, longitude);
        longitude = Math.max(126.878357, longitude);

        return new TMapPoint(latitude, longitude);
    }

    public TMapPoint randomTMapPoint2() {
        double latitude = ((double) Math.random()) * (37.770555 - 37.404194) + 37.483086;
        double longitude = ((double) Math.random()) * (127.426043 - 126.770296) + 126.878357;

        latitude = Math.min(37.770555, latitude);
        latitude = Math.max(37.404194, latitude);

        longitude = Math.min(127.426043, longitude);
        longitude = Math.max(126.770296, longitude);

        // LogManager.printLog("randomTMapPoint" + latitude + " " + longitude);

        return new TMapPoint(latitude, longitude);
    }
}