from setuptools import find_packages, setup

package_name = 'gps_imu_tf_publisher'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/tf_publisher.launch.py']),  # Launch 파일 포함
    ],
    install_requires=['setuptools', 'pyproj'],  # pyproj 추가
    zip_safe=True,
    maintainer='yun',
    maintainer_email='dbswkd76@naver.com',
    description='GPS 및 IMU 기반 TF 변환 패키지',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'gps_transform = gps_imu_tf_publisher.gps_transform:main',
            'imu_to_odom = gps_imu_tf_publisher.imu_to_odom:main',
            'tf_publisher = gps_imu_tf_publisher.tf_publisher:main',
        ],
    },
)
