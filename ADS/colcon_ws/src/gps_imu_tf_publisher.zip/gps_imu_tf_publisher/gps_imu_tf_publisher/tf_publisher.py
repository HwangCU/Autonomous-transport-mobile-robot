import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
import tf2_ros

class GPSToBaseLink(Node):
    def __init__(self):
        super().__init__('gps_to_base_link_node')
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        self.timer = self.create_timer(0.1, self.publish_tf)  # 0.1초마다 TF 전송

    def publish_tf(self):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()  # 현재 시간 설정
        t.header.frame_id = "gps_link"  # 부모 프레임
        t.child_frame_id = "base_link"  # 자식 프레임

        # GPS 기준으로 base_link의 위치를 설정 (일반적으로 0,0,0 유지)
        t.transform.translation.x = 0.0
        t.transform.translation.y = 0.0
        t.transform.translation.z = 0.0

        # 기본적인 방향 설정 (기본적으로 회전 없음)
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = 0.0
        t.transform.rotation.w = 1.0

        # TF 브로드캐스트
        self.tf_broadcaster.sendTransform(t)

def main():
    rclpy.init()
    node = GPSToBaseLink()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
