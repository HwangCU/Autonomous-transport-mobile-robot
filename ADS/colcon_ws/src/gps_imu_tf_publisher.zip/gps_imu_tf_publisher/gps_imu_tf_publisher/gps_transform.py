import rclpy
from rclpy.node import Node
import pyproj
from sensor_msgs.msg import NavSatFix
from geometry_msgs.msg import TransformStamped
import tf2_ros

class GPSTransform(Node):
    def __init__(self):
        super().__init__('gps_transform_node')
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        self.gps_sub = self.create_subscription(NavSatFix, "/gps/fix", self.gps_callback, 10)
        self.utm_proj = pyproj.Proj(proj='utm', zone=52, ellps='WGS84', south=False)

    def gps_callback(self, msg):
        utm_x, utm_y = self.utm_proj(msg.longitude, msg.latitude)
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = "map"
        t.child_frame_id = "gps_link"
        t.transform.translation.x = utm_x
        t.transform.translation.y = utm_y
        t.transform.translation.z = msg.altitude
        t.transform.rotation.w = 1.0
        self.tf_broadcaster.sendTransform(t)

def main():
    rclpy.init()
    node = GPSTransform()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
